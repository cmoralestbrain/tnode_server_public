---
name: tnode-skill-store
description: Tienda de skills de TBrain. Úsala cuando el dueño te pida algo para lo que no tienes una skill o herramienta adecuada: busca por significado, instala la que sirva y úsala en el mismo turno. También para quitar skills de la Tienda.
---

# tnode-skill-store

Te da acceso a la **Tienda de skills** de TBrain: un catálogo curado de
skills (instrucciones probadas para tareas concretas) que puedes buscar e
instalar tú mismo cuando hagan falta para lograr lo que pide el dueño.

## Cuándo usarla

- El dueño pide algo y **no tienes** una skill o herramienta que lo resuelva
  bien (redactar un tipo de documento, seguir un procedimiento, etc.).
- El dueño te pide **buscar, instalar o quitar** una skill de la Tienda.

No la uses si ya tienes una skill que sirve: revisa primero las que tienes.
Instalar **no requiere permiso** del dueño: la Tienda solo trae skills
revisadas por TBrain y quedan solo para ti (nunca para clientes).

## Cómo invocar

```bash
STORE=~/.openclaw/workspace/skills/tnode-skill-store/bin/store.py

python3 $STORE search "lo que necesita el dueño, en sus palabras"
python3 $STORE install <nombre>
python3 $STORE list
python3 $STORE uninstall <nombre>                    # solo las que instalaste tú
python3 $STORE uninstall <nombre> --owner-confirmed  # el dueño pidió quitarla
```

Todo responde JSON.

## Pasos

1. **Busca** con la necesidad del dueño en lenguaje natural. Cada resultado
   trae `name`, `title`, `summary`, `score` (afinidad) e `installed`.
2. **Elige** el resultado con mejor `score` que de verdad cubra el pedido.
   Si ninguno se acerca, díselo al dueño con honestidad; no instales por
   instalar.
3. **Instala** con `install <nombre>`. La respuesta trae `skillMd`: **léelo
   completo** y sigue sus pasos en este mismo turno para entregar lo que pidió.
4. **Si no sirvió** (no cubre lo que pidió o el resultado no es el esperado):
   quítala con `uninstall <nombre>` y prueba la siguiente opción.
   **Máximo 3 intentos.** Después dile al dueño qué intentaste y cuál se
   acercó más.

## Reglas

- **Nunca digas «listo» si la skill falló** o si no entregaste lo pedido.
- Si un resultado trae `removedByOwner: true`, **no lo instales**: el dueño
  la quitó. Solo él puede reinstalarla desde su app.
- Errores al instalar:
  - `harness_not_supported` o `requires_unavailable`: esa skill no funciona en
    este nodo; prueba otra.
  - `name_taken`: ya existe una skill de plataforma con ese nombre; usa esa.
  - `sha_mismatch` o `bundle_invalid`: el paquete no pasó la verificación;
    no reintentes la misma, avisa al dueño.
- **Quitar**: las que instalaste tú las puedes quitar sin preguntar si no
  sirvieron. Las que instaló el dueño (`needs_owner_confirmation`) solo con
  su confirmación explícita en el chat; entonces usa `--owner-confirmed`.
- Si `list` muestra muchas skills de la Tienda sin usar (`unused: true`,
  `sessionsSinceUse` alto o `lastUsedAt` viejo), puedes **sugerirle** al dueño quitarlas para
  que respondas más rápido. Nunca las quites sin que te lo confirme.
- Esto es solo para ti, el agente principal del dueño. Nunca en
  conversaciones con clientes, invitados ni otros agentes.
