-- tnode-bet — semilla de catálogos v0.1
INSERT OR IGNORE INTO sport VALUES ('soccer','Fútbol Soccer'),('nfl','NFL');

INSERT OR IGNORE INTO provider VALUES
 ('api_football','API-Football (api-sports.io)','both','Stats desde 2010 + odds pre-match (~30 casas, ~100 bets), refresh ~3h, ventana 1-14 días. No retiene odds históricos: snapshotear.'),
 ('api_american_football','API-American-Football (api-sports.io)','both','Misma cuenta que api_football.'),
 ('odds_api','The Odds API','odds','OPCIONAL fase 3: cierre de alta precisión. Región eu: Pinnacle/1xBet/Marathonbet.'),
 ('nflverse','nflverse (nflreadpy)','stats','PBP + schedules con líneas históricas. Gratis.'),
 ('footballdata','football-data.co.uk','both','CSV histórico con cierres Pinnacle. Gratis.'),
 ('understat','Understat','stats','xG top-5 Europa. Scrape.'),
 ('fbref','FBref','stats','xG Liga MX (Opta). Scrape con cache.');

INSERT OR IGNORE INTO country VALUES
 ('MX','México','https://media.api-sports.io/flags/mx.svg'),
 ('GB','Reino Unido','https://media.api-sports.io/flags/gb.svg'),
 ('ES','España','https://media.api-sports.io/flags/es.svg'),
 ('IT','Italia','https://media.api-sports.io/flags/it.svg'),
 ('DE','Alemania','https://media.api-sports.io/flags/de.svg'),
 ('FR','Francia','https://media.api-sports.io/flags/fr.svg'),
 ('US','Estados Unidos','https://media.api-sports.io/flags/us.svg'),
 ('INT','Internacional',NULL);

-- Inventario de ligas. Sólo 4 vienen ENCENDIDAS de fábrica (collect_enabled=1, historial 2 años);
-- el resto está en inventario (active=1) para que el agente las ofrezca y el usuario las prenda.
-- En producción `sync inventory` carga las ~1,100 ligas de API-Football /leagues con collect_enabled=0.
-- logo_url soccer = media.api-sports.io/football/leagues/{id}.png (ids a VERIFICAR); NFL = ESPN CDN
INSERT OR IGNORE INTO competition
 (id,sport_id,country_code,name,tier,format,logo_url,active,collect_enabled,collect_since,history_years,collect_requested_at,collect_requested_by,backfill_status) VALUES
 ('ligamx','soccer','MX','Liga MX',1,'split-season','https://media.api-sports.io/football/leagues/262.png',1,1,'2024-09-05',2,'2026-09-05T00:00:00Z','seed','pending'),
 ('epl','soccer','GB','Premier League',1,'league','https://media.api-sports.io/football/leagues/39.png',1,1,'2024-09-05',2,'2026-09-05T00:00:00Z','seed','pending'),
 ('laliga','soccer','ES','LaLiga',1,'league','https://media.api-sports.io/football/leagues/140.png',1,1,'2024-09-05',2,'2026-09-05T00:00:00Z','seed','pending'),
 ('nfl','nfl','US','National Football League',1,'league+playoff','https://a.espncdn.com/i/teamlogos/leagues/500/nfl.png',1,1,'2024-09-05',2,'2026-09-05T00:00:00Z','seed','pending'),
 -- inventario (apagadas)
 ('seriea','soccer','IT','Serie A',1,'league','https://media.api-sports.io/football/leagues/135.png',1,0,NULL,2,NULL,NULL,'none'),
 ('bundesliga','soccer','DE','Bundesliga',1,'league','https://media.api-sports.io/football/leagues/78.png',1,0,NULL,2,NULL,NULL,'none'),
 ('ligue1','soccer','FR','Ligue 1',1,'league','https://media.api-sports.io/football/leagues/61.png',1,0,NULL,2,NULL,NULL,'none'),
 ('ucl','soccer','INT','UEFA Champions League',1,'cup','https://media.api-sports.io/football/leagues/2.png',1,0,NULL,2,NULL,NULL,'none'),
 ('mls','soccer','US','MLS',1,'league+playoff','https://media.api-sports.io/football/leagues/253.png',1,0,NULL,2,NULL,NULL,'none'),
 ('ligamx_exp','soccer','MX','Liga de Expansión MX',2,'split-season',NULL,1,0,NULL,2,NULL,NULL,'none');

INSERT OR IGNORE INTO season VALUES
 ('ligamx-2026-ap','ligamx','Apertura 2026','2026-07-17','2026-12-20',1),
 ('epl-2026-27','epl','2026-27','2026-08-15','2027-05-23',1),
 ('nfl-2026','nfl','2026','2026-09-10','2027-02-14',1);

-- logo_url de bookmakers: ningún proveedor los da → assets propios (subir a Storage/CF, mismo patrón que avatares)
INSERT OR IGNORE INTO bookmaker (id,name,is_sharp,region,active) VALUES
 ('pinnacle','Pinnacle',1,'eu',1),
 ('betfair_ex','Betfair Exchange',1,'uk',1),
 ('onexbet','1xBet',0,'eu',1),
 ('marathonbet','Marathonbet',0,'eu',1),
 ('bet365','Bet365',0,'uk',1),
 ('caliente','Caliente.mx',0,'mx',1),
 ('codere','Codere',0,'mx',1),
 ('betmgm','BetMGM',0,'us',1),
 ('draftkings','DraftKings',0,'us',1),
 ('fanduel','FanDuel',0,'us',1),
 ('market_avg','Promedio del mercado (pseudo-casa para CLV)',1,NULL,1);

-- keys de cada proveedor para los bookmakers (The Odds API usa estas keys en región eu/uk/us)
INSERT OR IGNORE INTO external_id VALUES
 ('bookmaker','pinnacle','odds_api','pinnacle'),
 ('bookmaker','betfair_ex','odds_api','betfair_ex_eu'),
 ('bookmaker','onexbet','odds_api','onexbet'),
 ('bookmaker','marathonbet','odds_api','marathonbet'),
 ('bookmaker','bet365','odds_api','bet365'),  -- verificar: bet365 puede requerir plan pago
 ('bookmaker','betmgm','odds_api','betmgm'),
 ('bookmaker','draftkings','odds_api','draftkings'),
 ('bookmaker','fanduel','odds_api','fanduel'),
 -- API-Football bookmaker ids (VERIFICAR con GET /odds/bookmakers al firmar)
 ('bookmaker','pinnacle','api_football','4'),
 ('bookmaker','onexbet','api_football','11'),
 ('bookmaker','marathonbet','api_football','2'),
 ('bookmaker','bet365','api_football','8'),
 -- competiciones
 ('competition','ligamx','odds_api','soccer_mexico_ligamx'),
 ('competition','epl','odds_api','soccer_epl'),
 ('competition','laliga','odds_api','soccer_spain_la_liga'),
 ('competition','nfl','odds_api','americanfootball_nfl'),
 ('competition','ligamx','api_football','262'),  -- VERIFICAR
 ('competition','epl','api_football','39'),
 ('competition','laliga','api_football','140'),
 ('competition','epl','footballdata','E0'),
 ('competition','laliga','footballdata','SP1'),
 ('competition','ligamx','footballdata','MEX');

-- ───────── Catálogo de mercados ─────────
-- code, sport, nombre, category, stat, scope, period, uses_line, selections, settle_from, model_ready, active
INSERT OR IGNORE INTO market_type VALUES
 -- Soccer · resultado
 ('1X2',            'soccer','Ganador del partido',            'result',       'result','match','FT',0,'["home","draw","away"]','event_result',1,1),
 ('DC',             'soccer','Doble oportunidad',              'double_chance','result','match','FT',0,'["1X","X2","12"]',      'event_result',1,1),
 ('DNB',            'soccer','Empate no válido',               'draw_no_bet',  'result','match','FT',0,'["home","away"]',       'event_result',1,1),
 ('AH',             'soccer','Hándicap asiático',              'handicap',     'goals', 'match','FT',1,'["home","away"]',       'event_result',1,1),
 ('EH',             'soccer','Hándicap europeo (3 vías)',      'handicap',     'goals', 'match','FT',1,'["home","draw","away"]','event_result',1,1),
 ('CS',             'soccer','Marcador exacto',                'correct_score','goals', 'match','FT',0,'["*"]',                 'event_result',1,1),
 ('HTFT',           'soccer','Medio tiempo / final',           'ht_ft',        'result','match','FT',0,'["*"]',                 'event_result.ht',0,1),
 -- Soccer · goles
 ('GOALS_OU',       'soccer','Total de goles del encuentro',   'totals',       'goals', 'match','FT',1,'["over","under"]',      'event_result',1,1),
 ('GOALS_OU_HOME',  'soccer','Total de goles del local',       'team_totals',  'goals', 'home', 'FT',1,'["over","under"]',      'event_result',1,1),
 ('GOALS_OU_AWAY',  'soccer','Total de goles del visitante',   'team_totals',  'goals', 'away', 'FT',1,'["over","under"]',      'event_result',1,1),
 ('BTTS',           'soccer','Ambos equipos anotan',           'both_score',   'goals', 'match','FT',0,'["yes","no"]',          'event_result',1,1),
 ('GOALS_ODD_EVEN', 'soccer','Goles par / impar',              'odd_even',     'goals', 'match','FT',0,'["odd","even"]',        'event_result',1,1),
 ('CLEAN_SHEET_HOME','soccer','Local sin recibir gol',         'clean_sheet',  'goals', 'home', 'FT',0,'["yes","no"]',          'event_result',1,1),
 ('CLEAN_SHEET_AWAY','soccer','Visitante sin recibir gol',     'clean_sheet',  'goals', 'away', 'FT',0,'["yes","no"]',          'event_result',1,1),
 ('TEAM_SCORES_HOME','soccer','Local anota',                   'team_to_score','goals', 'home', 'FT',0,'["yes","no"]',          'event_result',1,1),
 ('TEAM_SCORES_AWAY','soccer','Visitante anota',               'team_to_score','goals', 'away', 'FT',0,'["yes","no"]',          'event_result',1,1),
 -- Soccer · primer tiempo
 ('1H_1X2',         'soccer','Ganador primer tiempo',          'result',       'result','match','1H',0,'["home","draw","away"]','event_result.ht',0,1),
 ('1H_GOALS_OU',    'soccer','Total de goles primer tiempo',   'totals',       'goals', 'match','1H',1,'["over","under"]',      'event_result.ht',0,1),
 ('1H_BTTS',        'soccer','Ambos anotan primer tiempo',     'both_score',   'goals', 'match','1H',0,'["yes","no"]',          'event_result.ht',0,1),
 -- Soccer · córners y tarjetas (liquidan desde stats, no desde el marcador)
 ('CORNERS_OU',     'soccer','Total de córners',               'totals',       'corners','match','FT',1,'["over","under"]',     'soccer_event_stats.corners',0,1),
 ('CORNERS_OU_HOME','soccer','Córners del local',              'team_totals',  'corners','home', 'FT',1,'["over","under"]',     'soccer_event_stats.corners',0,1),
 ('CORNERS_OU_AWAY','soccer','Córners del visitante',          'team_totals',  'corners','away', 'FT',1,'["over","under"]',     'soccer_event_stats.corners',0,1),
 ('CORNERS_AH',     'soccer','Hándicap asiático de córners',   'handicap',     'corners','match','FT',1,'["home","away"]',      'soccer_event_stats.corners',0,1),
 ('CORNERS_1X2',    'soccer','Más córners (3 vías)',           'result',       'corners','match','FT',0,'["home","draw","away"]','soccer_event_stats.corners',0,1),
 ('CARDS_OU',       'soccer','Total de tarjetas',              'totals',       'cards', 'match','FT',1,'["over","under"]',      'soccer_event_stats.cards',0,1),
 -- NFL
 ('ML',             'nfl','Moneyline',                         'result',       'result','match','FT',0,'["home","away"]',       'event_result',1,1),
 ('SPREAD',         'nfl','Hándicap de puntos',                'handicap',     'points','match','FT',1,'["home","away"]',       'event_result',1,1),
 ('TOTAL',          'nfl','Total de puntos',                   'totals',       'points','match','FT',1,'["over","under"]',      'event_result',1,1),
 ('TEAM_TOTAL_HOME','nfl','Puntos del local',                  'team_totals',  'points','home', 'FT',1,'["over","under"]',      'event_result',1,1),
 ('TEAM_TOTAL_AWAY','nfl','Puntos del visitante',              'team_totals',  'points','away', 'FT',1,'["over","under"]',      'event_result',1,1),
 ('1H_ML',          'nfl','Moneyline primera mitad',           'result',       'result','match','1H',0,'["home","away"]',       'event_result.ht',0,1),
 ('1H_SPREAD',      'nfl','Hándicap primera mitad',            'handicap',     'points','match','1H',1,'["home","away"]',       'event_result.ht',0,1),
 ('1H_TOTAL',       'nfl','Total primera mitad',               'totals',       'points','match','1H',1,'["over","under"]',      'event_result.ht',0,1),
 ('TOTAL_ODD_EVEN', 'nfl','Puntos par / impar',                'odd_even',     'points','match','FT',0,'["odd","even"]',        'event_result',1,1);

-- ───────── Mapeo de mercados por proveedor ─────────
-- API-Football: ids de /odds/bets (SUPUESTOS de docs v3; verified=0 hasta confirmar con la key)
INSERT OR IGNORE INTO provider_market_map VALUES
 ('api_football','1', 'Match Winner',              '1X2',            '{"Home":"home","Draw":"draw","Away":"away"}', NULL, 0),
 ('api_football','12','Double Chance',             'DC',             '{"Home/Draw":"1X","Draw/Away":"X2","Home/Away":"12"}', NULL, 0),
 ('api_football','4', 'Asian Handicap',            'AH',             '{"Home":"home","Away":"away"}', '^(Home|Away) ([+-]?\d+(?:\.\d+)?)$', 0),
 ('api_football','5', 'Goals Over/Under',          'GOALS_OU',       '{"Over":"over","Under":"under"}', '^(Over|Under) (\d+(?:\.\d+)?)$', 0),
 ('api_football','16','Total - Home',              'GOALS_OU_HOME',  '{"Over":"over","Under":"under"}', '^(Over|Under) (\d+(?:\.\d+)?)$', 0),
 ('api_football','17','Total - Away',              'GOALS_OU_AWAY',  '{"Over":"over","Under":"under"}', '^(Over|Under) (\d+(?:\.\d+)?)$', 0),
 ('api_football','8', 'Both Teams Score',          'BTTS',           '{"Yes":"yes","No":"no"}', NULL, 0),
 ('api_football','10','Exact Score',               'CS',             NULL, '^(\d+):(\d+)$', 0),
 ('api_football','13','First Half Winner',         '1H_1X2',         '{"Home":"home","Draw":"draw","Away":"away"}', NULL, 0),
 ('api_football','6', 'Goals Over/Under First Half','1H_GOALS_OU',   '{"Over":"over","Under":"under"}', '^(Over|Under) (\d+(?:\.\d+)?)$', 0),
 ('api_football','21','Odd/Even',                  'GOALS_ODD_EVEN', '{"Odd":"odd","Even":"even"}', NULL, 0),
 ('api_football','27','Clean Sheet - Home',        'CLEAN_SHEET_HOME','{"Yes":"yes","No":"no"}', NULL, 0),
 ('api_football','28','Clean Sheet - Away',        'CLEAN_SHEET_AWAY','{"Yes":"yes","No":"no"}', NULL, 0),
 ('api_football','45','Corners Over Under',        'CORNERS_OU',     '{"Over":"over","Under":"under"}', '^(Over|Under) (\d+(?:\.\d+)?)$', 0),
 ('api_football','7', 'HT/FT Double',              'HTFT',           NULL, '^(Home|Draw|Away)/(Home|Draw|Away)$', 0);

-- football-data.co.uk: columnas del CSV (verificadas en notes.txt)
INSERT OR IGNORE INTO provider_market_map VALUES
 ('footballdata','H/D/A',  'Home/Draw/Away odds (B365H, PSH, PSCH…)', '1X2',      '{"H":"home","D":"draw","A":"away"}', NULL, 1),
 ('footballdata','>2.5',   'Over/Under 2.5 (B365>2.5, P>2.5, Avg>2.5)','GOALS_OU', '{">":"over","<":"under"}', NULL, 1),
 ('footballdata','AH',     'Asian handicap (AHh, B365AHH, PAHH)',      'AH',       '{"AHH":"home","AHA":"away"}', NULL, 1);

-- nflverse schedules: columnas del schedule
INSERT OR IGNORE INTO provider_market_map VALUES
 ('nflverse','moneyline',  'home_moneyline / away_moneyline',   'ML',     '{"home_moneyline":"home","away_moneyline":"away"}', NULL, 1),
 ('nflverse','spread_line','spread_line + home/away_spread_odds','SPREAD', '{"home_spread_odds":"home","away_spread_odds":"away"}', NULL, 1),
 ('nflverse','total_line', 'total_line + over_odds/under_odds',  'TOTAL',  '{"over_odds":"over","under_odds":"under"}', NULL, 1);
INSERT OR IGNORE INTO setting(key, value) VALUES ('notify_settled', 'on');
