-- 008: marca de "ya avisé que este pick se cerró".
--
-- El dueño quiere retroalimentación cada que se liquida un pick (resultado,
-- unidades, probabilidad, ventaja, CLV). El cron `tnode-bet-settled` corre
-- cada hora y pregunta `report settled --only-new`; sin esta marca repetiría
-- los mismos cierres cada hora. Los picks ya liquidados ANTES de esta
-- migración se marcan como avisados: no se le vuelve a contar historia vieja.

ALTER TABLE recommendation ADD COLUMN settled_notified_at TEXT;
CREATE INDEX IF NOT EXISTS ix_recommendation_settled_notice
  ON recommendation(settled_notified_at, settled_at);

UPDATE recommendation
   SET settled_notified_at = COALESCE(settled_at, issued_at)
 WHERE outcome IS NOT NULL AND settled_notified_at IS NULL;

INSERT OR IGNORE INTO setting(key, value) VALUES
  ('notify_settled', 'on');        -- 'on' | 'off': aviso de picks cerrados
