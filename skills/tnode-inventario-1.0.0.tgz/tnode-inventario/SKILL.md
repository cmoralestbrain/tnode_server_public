---
name: tnode-inventario
description: Flujo de resurtido — lee el inventario del dueño (sheet ya parseado a JSON) y estampa el tracking de órdenes. Para inventario usa siempre este skill, no tnode-drive.
---

# tnode-inventario

Herramienta del **flujo de resurtido**: lee el Google Sheet del
inventario del dueño (ya parseado a JSON) y **estampa el tracking** de
una orden de resurtido en el sheet (columnas ORDEN / ESTADO / FECHA
AUTORIZACION / COMENTARIO). Para el inventario usa SIEMPRE este skill —
no el skill `drive`.

## Cuándo usarlo

- Al **revisar el inventario** (corrida programada o pregunta del dueño):
  `leer` te da las filas frescas para aplicar la regla de resurtido.
- **Después de enviar una orden** a un proveedor (`guest_send` con
  `approvalId`): `estampar --fase enviado`.
- **Cuando el proveedor decide** (te llega un mensaje "PROVEEDOR …
  ACEPTÓ/RECHAZÓ la orden …"): `estampar --fase resultado`.

## Cómo invocar

```bash
SKILL=~/.openclaw/workspace/skills/tnode-inventario/bin/inventario.py

python3 $SKILL leer                                    # filas del sheet en JSON
python3 $SKILL leer --sheet INVENTARIO                 # otro nombre de sheet
python3 $SKILL estampar --orden <approvalId> --fase enviado
python3 $SKILL estampar --orden <approvalId> --fase resultado
```

## Reglas

1. **`leer` SIEMPRE descarga el sheet fresco.** Nunca contestes sobre el
   inventario con datos de una lectura anterior de la conversación.
2. **`estampar` no recibe valores** — el servidor los deriva del registro
   de la autorización (`approvalId`). Tú solo das el id y la fase; no
   inventes códigos, fechas ni estados.
3. `--fase resultado` solo funciona cuando el proveedor ya decidió; si
   regresa `supplier_not_decided`, la decisión aún no llega — no la
   inventes.
4. Si regresa `notFound` con alguna línea, repórtalo al dueño tal cual
   (la fila ya no existe en el sheet con ese PRODUCTO+SUCURSAL).
