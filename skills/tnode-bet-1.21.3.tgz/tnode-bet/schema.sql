-- tnode-bet — esquema SQLite v0.1 (2026-09-05)
-- Catálogos compartidos + eventos genéricos + satélites por deporte + momios + modelo/evaluación.
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- ───────────────────────── Catálogos compartidos ─────────────────────────
CREATE TABLE IF NOT EXISTS sport (
  id        TEXT PRIMARY KEY,              -- 'soccer' | 'nfl'
  name      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS provider (
  id        TEXT PRIMARY KEY,              -- 'api_football','odds_api','nflverse','footballdata','understat','fbref'
  name      TEXT NOT NULL,
  kind      TEXT NOT NULL CHECK (kind IN ('stats','odds','both')),
  notes     TEXT
);

CREATE TABLE IF NOT EXISTS country (
  code      TEXT PRIMARY KEY,              -- ISO-3166 alpha-2 ('MX','GB','US','INT')
  name      TEXT NOT NULL,
  flag_url  TEXT                           -- API-Football: https://media.api-sports.io/flags/mx.svg
);

CREATE TABLE IF NOT EXISTS competition (
  id           TEXT PRIMARY KEY,           -- 'ligamx','epl','nfl','ucl'
  sport_id     TEXT NOT NULL REFERENCES sport(id),
  country_code TEXT REFERENCES country(code),
  name         TEXT NOT NULL,
  tier         INTEGER,                    -- 1 = máxima división
  format       TEXT,                       -- 'league','league+playoff','cup','split-season'
  logo_url     TEXT,                       -- API-Football: https://media.api-sports.io/football/leagues/262.png
  active       INTEGER NOT NULL DEFAULT 1, -- 1 = existe en el proveedor (inventario); NO implica que se recolecte
  -- Recolección acotada: sólo las ligas con collect_enabled=1 entran a sync/odds/backfill.
  collect_enabled      INTEGER NOT NULL DEFAULT 0,
  collect_since        TEXT,               -- fecha desde la que se construye historial (= solicitud − history_years)
  history_years        INTEGER NOT NULL DEFAULT 2 CHECK (history_years BETWEEN 1 AND 2),
  collect_requested_at TEXT,
  collect_requested_by TEXT,               -- 'seed' | id de usuario/guest | 'owner'
  collect_disabled_at  TEXT,               -- apagar NO borra: conserva lo recolectado y deja de traer nuevo
  backfill_status      TEXT NOT NULL DEFAULT 'none' CHECK (backfill_status IN ('none','pending','running','done','error'))
);
CREATE INDEX IF NOT EXISTS ix_competition_collect ON competition(sport_id, collect_enabled);

CREATE TABLE IF NOT EXISTS season (
  id             TEXT PRIMARY KEY,         -- 'ligamx-2026-ap','epl-2026-27','nfl-2026'
  competition_id TEXT NOT NULL REFERENCES competition(id),
  label          TEXT NOT NULL,            -- 'Apertura 2026', '2026-27', '2026'
  start_date     TEXT,                     -- ISO date
  end_date       TEXT,
  is_current     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS venue (
  id        INTEGER PRIMARY KEY,
  name      TEXT NOT NULL,
  city      TEXT,
  country_code TEXT REFERENCES country(code),
  image_url TEXT,                          -- API-Football: media.api-sports.io/football/venues/{id}.png
  altitude_m INTEGER,                      -- relevante en Liga MX (CDMX/Toluca)
  roof      TEXT,                          -- NFL: 'outdoors','dome','closed','open'
  surface   TEXT                           -- NFL: 'grass','fieldturf',…
);

CREATE TABLE IF NOT EXISTS team (
  id           INTEGER PRIMARY KEY,
  sport_id     TEXT NOT NULL REFERENCES sport(id),
  name         TEXT NOT NULL,              -- canónico ('Club América','Kansas City Chiefs')
  short_name   TEXT,                       -- 'América','KC'
  country_code TEXT REFERENCES country(code),
  home_venue_id INTEGER REFERENCES venue(id),
  logo_url     TEXT,                       -- soccer: media.api-sports.io/football/teams/{id}.png · nfl: team_logo_espn (nflverse)
  wordmark_url TEXT,                       -- nfl: team_wordmark (nflverse); NULL en soccer
  color_primary   TEXT,                    -- hex '#RRGGBB' (nflverse team_color; soccer opcional)
  color_secondary TEXT,
  active       INTEGER NOT NULL DEFAULT 1,
  UNIQUE (sport_id, name)
);

-- Alias de nombres para casar strings de distintos proveedores (Odds API usa nombres, no ids)
CREATE TABLE IF NOT EXISTS team_alias (
  team_id  INTEGER NOT NULL REFERENCES team(id) ON DELETE CASCADE,
  alias    TEXT NOT NULL,
  provider_id TEXT REFERENCES provider(id),  -- NULL = alias genérico
  PRIMARY KEY (alias, provider_id)
);

-- Mapa entidad ↔ id externo por proveedor. Sin esto el cruce stats↔momios se rompe.
CREATE TABLE IF NOT EXISTS external_id (
  entity_type TEXT NOT NULL CHECK (entity_type IN ('team','competition','season','event','venue','bookmaker','market')),
  entity_id   TEXT NOT NULL,
  provider_id TEXT NOT NULL REFERENCES provider(id),
  external_id TEXT NOT NULL,
  PRIMARY KEY (entity_type, entity_id, provider_id),
  UNIQUE (entity_type, provider_id, external_id)
);

CREATE TABLE IF NOT EXISTS bookmaker (
  id        TEXT PRIMARY KEY,              -- 'pinnacle','onexbet','marathonbet','bet365','caliente'
  name      TEXT NOT NULL,
  is_sharp  INTEGER NOT NULL DEFAULT 0,    -- 1 = referencia para CLV
  region    TEXT,                          -- 'eu','uk','us','mx'
  logo_url  TEXT,                          -- The Odds API no da logos; API-Football tampoco → asset propio en Storage/CF
  active    INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS market_type (
  code        TEXT PRIMARY KEY,            -- 'GOALS_OU','GOALS_OU_HOME','CORNERS_OU','DC','1X2'…
  sport_id    TEXT NOT NULL REFERENCES sport(id),
  name        TEXT NOT NULL,               -- nombre en español para el agente
  category    TEXT NOT NULL CHECK (category IN
              ('result','double_chance','draw_no_bet','totals','team_totals','handicap',
               'both_score','correct_score','odd_even','clean_sheet','team_to_score','ht_ft')),
  stat        TEXT NOT NULL CHECK (stat IN ('result','goals','corners','cards','points')),
  scope       TEXT NOT NULL CHECK (scope IN ('match','home','away')),
  period      TEXT NOT NULL DEFAULT 'FT' CHECK (period IN ('FT','1H','2H')),  -- NFL: FT incluye OT
  uses_line   INTEGER NOT NULL DEFAULT 0,  -- 1 = requiere línea (2.5, -3.5, 9.5 córners…)
  selections  TEXT NOT NULL,               -- JSON canónico: ["home","draw","away"] | ["over","under"] | ["1X","X2","12"] | ["yes","no"] | ["odd","even"] | ["*"] (correct score / HT-FT: valor libre)
  settle_from TEXT NOT NULL,               -- de dónde liquida: 'event_result' | 'soccer_event_stats.corners' | 'soccer_event_stats.cards' | 'event_result.ht'
  model_ready INTEGER NOT NULL DEFAULT 0,  -- 1 = el modelo de goles/puntos lo puede cotizar (fase actual)
  active      INTEGER NOT NULL DEFAULT 1
);

-- Cómo nombra cada proveedor el mercado y sus selecciones. Es el puente al insertar odds_snapshot.
CREATE TABLE IF NOT EXISTS provider_market_map (
  provider_id       TEXT NOT NULL REFERENCES provider(id),
  external_market_id TEXT NOT NULL,        -- API-Football: bet id ('5'); footballdata: prefijo de columna ('>2.5')
  external_label    TEXT,                  -- 'Goals Over/Under'
  market_code       TEXT NOT NULL REFERENCES market_type(code),
  selection_map_json TEXT,                 -- {"Home":"home","Draw":"draw","Away":"away","Yes":"yes","No":"no"}
  line_regex        TEXT,                  -- '^(Over|Under) (\\d+(?:\\.\\d+)?)$' → grupo1=selección, grupo2=línea
  verified          INTEGER NOT NULL DEFAULT 0,  -- 0 = id supuesto; poner 1 tras confirmar con /odds/bets
  PRIMARY KEY (provider_id, external_market_id)
);

-- ───────────────────────── Eventos (genérico) ─────────────────────────
CREATE TABLE IF NOT EXISTS event (
  id             INTEGER PRIMARY KEY,
  sport_id       TEXT NOT NULL REFERENCES sport(id),
  competition_id TEXT NOT NULL REFERENCES competition(id),
  season_id      TEXT NOT NULL REFERENCES season(id),
  round          TEXT,                     -- 'J5', 'Week 3', 'Cuartos ida'
  stage          TEXT,                     -- 'regular','playoff','final','group'
  home_team_id   INTEGER NOT NULL REFERENCES team(id),
  away_team_id   INTEGER NOT NULL REFERENCES team(id),
  venue_id       INTEGER REFERENCES venue(id),
  neutral        INTEGER NOT NULL DEFAULT 0,
  kickoff_utc    TEXT NOT NULL,            -- ISO-8601 UTC
  status         TEXT NOT NULL DEFAULT 'scheduled'
                 CHECK (status IN ('scheduled','live','finished','postponed','cancelled')),
  created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (season_id, home_team_id, away_team_id, kickoff_utc)
);
CREATE INDEX IF NOT EXISTS ix_event_kickoff ON event(sport_id, kickoff_utc);
CREATE INDEX IF NOT EXISTS ix_event_season  ON event(season_id, status);

CREATE TABLE IF NOT EXISTS event_result (
  event_id      INTEGER PRIMARY KEY REFERENCES event(id) ON DELETE CASCADE,
  home_score    INTEGER NOT NULL,
  away_score    INTEGER NOT NULL,
  home_ht       INTEGER,                   -- medio tiempo
  away_ht       INTEGER,
  extra_time    INTEGER NOT NULL DEFAULT 0,-- soccer: prórroga / NFL: OT
  home_score_ft INTEGER,                   -- soccer: 90' si hubo prórroga
  away_score_ft INTEGER,
  winner        TEXT CHECK (winner IN ('home','away','draw')),
  source_provider_id TEXT REFERENCES provider(id),
  settled_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ───────────────────────── Satélites Soccer ─────────────────────────
CREATE TABLE IF NOT EXISTS soccer_event_stats (   -- 1 fila por equipo por partido
  event_id      INTEGER NOT NULL REFERENCES event(id) ON DELETE CASCADE,
  team_id       INTEGER NOT NULL REFERENCES team(id),
  is_home       INTEGER NOT NULL,
  shots         INTEGER, shots_on_target INTEGER, shots_blocked INTEGER,
  corners       INTEGER, fouls INTEGER, offsides INTEGER,
  yellow_cards  INTEGER, red_cards INTEGER,
  possession_pct REAL,
  passes        INTEGER, pass_accuracy_pct REAL,
  xg            REAL, xga REAL,            -- fase 2 (Understat/FBref)
  xg_provider_id TEXT REFERENCES provider(id),
  PRIMARY KEY (event_id, team_id)
);

CREATE TABLE IF NOT EXISTS soccer_lineup (       -- fase 2: titulares/bajas
  event_id   INTEGER NOT NULL REFERENCES event(id) ON DELETE CASCADE,
  team_id    INTEGER NOT NULL REFERENCES team(id),
  formation  TEXT,
  starters_json TEXT,                      -- JSON [{player, pos}]
  missing_json  TEXT,                      -- JSON [{player, reason}]
  PRIMARY KEY (event_id, team_id)
);

-- ───────────────────────── Satélites NFL ─────────────────────────
CREATE TABLE IF NOT EXISTS nfl_event_detail (
  event_id      INTEGER PRIMARY KEY REFERENCES event(id) ON DELETE CASCADE,
  week          INTEGER NOT NULL,
  season_type   TEXT NOT NULL CHECK (season_type IN ('REG','POST','PRE')),
  game_id_nflverse TEXT,                   -- '2026_01_KC_BAL'
  roof          TEXT, surface TEXT,
  temp_f        INTEGER, wind_mph INTEGER,
  home_rest_days INTEGER, away_rest_days INTEGER,
  div_game      INTEGER,
  -- líneas históricas que trae el schedule de nflverse (ya “gratis”, útiles para backtest)
  spread_line   REAL, total_line REAL,
  home_moneyline INTEGER, away_moneyline INTEGER,
  home_qb       TEXT, away_qb TEXT
);

CREATE TABLE IF NOT EXISTS nfl_team_game_stats (  -- agregado desde play-by-play; 1 fila por equipo
  event_id       INTEGER NOT NULL REFERENCES event(id) ON DELETE CASCADE,
  team_id        INTEGER NOT NULL REFERENCES team(id),
  is_home        INTEGER NOT NULL,
  points         INTEGER,
  total_yards    INTEGER, pass_yards INTEGER, rush_yards INTEGER,
  plays          INTEGER, turnovers INTEGER, sacks_allowed INTEGER,
  third_down_pct REAL, red_zone_pct REAL,
  epa_per_play   REAL, pass_epa REAL, rush_epa REAL,
  success_rate   REAL,
  time_of_possession_sec INTEGER,
  PRIMARY KEY (event_id, team_id)
);

-- ───────────────────────── Momios (append-only) ─────────────────────────
CREATE TABLE IF NOT EXISTS odds_snapshot (
  id            INTEGER PRIMARY KEY,
  event_id      INTEGER NOT NULL REFERENCES event(id) ON DELETE CASCADE,
  bookmaker_id  TEXT NOT NULL REFERENCES bookmaker(id),
  market_code   TEXT NOT NULL REFERENCES market_type(code),
  line          REAL,                      -- NULL para 1X2/ML/BTTS
  selection     TEXT NOT NULL,             -- 'home','draw','away','over','under','yes','no'
  price_decimal REAL NOT NULL CHECK (price_decimal > 1.0),   -- CANÓNICO: siempre decimal; americano se deriva
  price_american INTEGER GENERATED ALWAYS AS (
                  CASE WHEN price_decimal >= 2.0 THEN CAST(ROUND((price_decimal - 1.0) * 100) AS INTEGER)
                       ELSE -CAST(ROUND(100.0 / (price_decimal - 1.0)) AS INTEGER) END) VIRTUAL,
  implied_prob  REAL GENERATED ALWAYS AS (1.0 / price_decimal) VIRTUAL,
  captured_at   TEXT NOT NULL,             -- ISO UTC
  minutes_to_kickoff INTEGER,              -- denormalizado para queries de cierre
  is_closing    INTEGER NOT NULL DEFAULT 0,-- último snapshot antes del kickoff (lo marca `settle`)
  provider_id   TEXT NOT NULL REFERENCES provider(id)
);
CREATE INDEX IF NOT EXISTS ix_odds_event_market ON odds_snapshot(event_id, market_code, line, selection, captured_at);
CREATE INDEX IF NOT EXISTS ix_odds_closing      ON odds_snapshot(event_id, is_closing) WHERE is_closing = 1;

-- Prueba de ausencia: cada consulta de momios registra qué encontró, para distinguir
-- "Marathonbet no publicó córners en este partido" de "todavía no lo consultamos".
CREATE TABLE IF NOT EXISTS odds_fetch (
  id            INTEGER PRIMARY KEY,
  event_id      INTEGER NOT NULL REFERENCES event(id) ON DELETE CASCADE,
  provider_id   TEXT NOT NULL REFERENCES provider(id),
  bookmaker_id  TEXT REFERENCES bookmaker(id),   -- NULL = la consulta cubrió todas las casas del proveedor
  captured_at   TEXT NOT NULL,
  markets_found TEXT NOT NULL DEFAULT '[]',       -- JSON de market_code encontrados, p.ej. ["1X2","GOALS_OU","BTTS"]
  rows_written  INTEGER NOT NULL DEFAULT 0,
  http_status   INTEGER
);
CREATE INDEX IF NOT EXISTS ix_odds_fetch_event ON odds_fetch(event_id, bookmaker_id, captured_at);

-- Cierre por (evento, book, mercado, línea, selección)
CREATE VIEW IF NOT EXISTS v_closing_odds AS
  SELECT o.* FROM odds_snapshot o
  WHERE o.is_closing = 1;

-- Mejor precio actual por selección (última captura por book)
CREATE VIEW IF NOT EXISTS v_latest_odds AS
  SELECT o.* FROM odds_snapshot o
  JOIN (SELECT event_id, bookmaker_id, market_code, line, selection, MAX(captured_at) AS mx
        FROM odds_snapshot GROUP BY 1,2,3,4,5) l
    ON l.event_id=o.event_id AND l.bookmaker_id=o.bookmaker_id AND l.market_code=o.market_code
   AND COALESCE(l.line,-999)=COALESCE(o.line,-999) AND l.selection=o.selection AND l.mx=o.captured_at;

-- ───────────────────────── Historial por market ─────────────────────────
-- Resultado liquidado de CADA market en CADA partido, derivado por `settle` desde event_result / stats
-- según market_type.settle_from. Es el "y" del modelo y del backtest: p.ej. ¿pegó over 2.5? ¿BTTS? ¿córners > 9.5?
CREATE TABLE IF NOT EXISTS market_result (
  event_id     INTEGER NOT NULL REFERENCES event(id) ON DELETE CASCADE,
  market_code  TEXT NOT NULL REFERENCES market_type(code),
  line         REAL,                       -- NULL en mercados sin línea
  selection    TEXT NOT NULL,
  outcome      TEXT NOT NULL CHECK (outcome IN ('win','loss','push','half_win','half_loss','void')),
  actual_value REAL,                       -- valor observado que liquidó: goles totales 3, córners 11, puntos 47…
  settled_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY (event_id, market_code, line, selection)
);
CREATE INDEX IF NOT EXISTS ix_market_result_market ON market_result(market_code, line, selection);
-- En SQLite NULL != NULL, así que la PK de arriba NO colapsa los mercados sin
-- línea (1X2, BTTS, ML…) y un INSERT OR REPLACE los duplicaría. El índice
-- sobre COALESCE sí los colapsa. Ver migrations/002.
CREATE UNIQUE INDEX IF NOT EXISTS ux_market_result_key
  ON market_result(event_id, market_code, COALESCE(line, -999), selection);

-- Historial de momios por market: apertura, cierre y movimiento por (evento, casa, market, línea, selección)
CREATE VIEW IF NOT EXISTS v_odds_history AS
  SELECT o.event_id, o.bookmaker_id, o.market_code, o.line, o.selection,
         MIN(o.captured_at)                                            AS opened_at,
         (SELECT price_decimal FROM odds_snapshot x WHERE x.event_id=o.event_id AND x.bookmaker_id=o.bookmaker_id
            AND x.market_code=o.market_code AND COALESCE(x.line,-999)=COALESCE(o.line,-999) AND x.selection=o.selection
            ORDER BY x.captured_at ASC  LIMIT 1)                       AS opening_price,
         MAX(o.captured_at)                                            AS last_at,
         (SELECT price_decimal FROM odds_snapshot x WHERE x.event_id=o.event_id AND x.bookmaker_id=o.bookmaker_id
            AND x.market_code=o.market_code AND COALESCE(x.line,-999)=COALESCE(o.line,-999) AND x.selection=o.selection
            ORDER BY x.captured_at DESC LIMIT 1)                       AS last_price,
         MAX(CASE WHEN o.is_closing=1 THEN o.price_decimal END)        AS closing_price,
         COUNT(*)                                                      AS n_snapshots
  FROM odds_snapshot o
  GROUP BY o.event_id, o.bookmaker_id, o.market_code, o.line, o.selection;

-- Historial por market y por equipo: cada partido del equipo con el resultado de ese market (base de "últimos N")
CREATE VIEW IF NOT EXISTS v_team_market_history AS
  SELECT t.id AS team_id, e.id AS event_id, e.kickoff_utc, e.competition_id, e.season_id,
         CASE WHEN e.home_team_id=t.id THEN 'home' ELSE 'away' END AS side,
         mr.market_code, mr.line, mr.selection, mr.outcome, mr.actual_value
  FROM market_result mr
  JOIN event e ON e.id = mr.event_id
  JOIN team  t ON t.id IN (e.home_team_id, e.away_team_id);

-- Cobertura observada: qué casa publica qué mercado en qué competencia (derivada, sin mantenimiento manual).
-- El agente la usa para saber dónde buscar y para no prometer un mercado que esa casa no cotiza.
CREATE VIEW IF NOT EXISTS v_bookmaker_market_coverage AS
  SELECT e.competition_id, o.bookmaker_id, o.market_code,
         COUNT(DISTINCT o.event_id)                                   AS events_with_odds,
         (SELECT COUNT(*) FROM event e2
            WHERE e2.competition_id = e.competition_id
              AND EXISTS (SELECT 1 FROM odds_fetch f WHERE f.event_id = e2.id))  AS events_fetched,
         MAX(o.captured_at)                                           AS last_seen
  FROM odds_snapshot o JOIN event e ON e.id = o.event_id
  GROUP BY e.competition_id, o.bookmaker_id, o.market_code;

-- Mejor precio disponible por selección entre las casas que SÍ publicaron ese mercado (n_books dice cuántas)
CREATE VIEW IF NOT EXISTS v_best_price AS
  SELECT event_id, market_code, line, selection,
         MAX(price_decimal) AS best_price,
         (SELECT bookmaker_id FROM v_latest_odds b
            WHERE b.event_id=a.event_id AND b.market_code=a.market_code
              AND COALESCE(b.line,-999)=COALESCE(a.line,-999) AND b.selection=a.selection
            ORDER BY b.price_decimal DESC LIMIT 1)                    AS best_bookmaker_id,
         COUNT(DISTINCT bookmaker_id) AS n_books,
         AVG(price_decimal)           AS avg_price
  FROM v_latest_odds a
  GROUP BY event_id, market_code, line, selection;

-- ───────────────────────── Modelo y evaluación ─────────────────────────
CREATE TABLE IF NOT EXISTS model_run (
  id             INTEGER PRIMARY KEY,
  sport_id       TEXT NOT NULL REFERENCES sport(id),
  competition_id TEXT REFERENCES competition(id),  -- NULL = multi-liga
  model_name     TEXT NOT NULL,            -- 'poisson','dixon_coles','bivariate_poisson','nfl_elo_logit'
  model_version  TEXT NOT NULL,
  params_json    TEXT NOT NULL,            -- xi, ventana, home_adv, etc.
  train_from     TEXT, train_to TEXT,
  metrics_json   TEXT,                     -- log_loss, brier, rps, n
  fitted_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  is_active      INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS team_rating (   -- parámetros ajustados por equipo (ataque/defensa/elo)
  model_run_id INTEGER NOT NULL REFERENCES model_run(id) ON DELETE CASCADE,
  team_id      INTEGER NOT NULL REFERENCES team(id),
  attack       REAL, defence REAL, rating REAL,
  PRIMARY KEY (model_run_id, team_id)
);

CREATE TABLE IF NOT EXISTS prediction (
  id           INTEGER PRIMARY KEY,
  event_id     INTEGER NOT NULL REFERENCES event(id) ON DELETE CASCADE,
  model_run_id INTEGER NOT NULL REFERENCES model_run(id),
  market_code  TEXT NOT NULL REFERENCES market_type(code),
  line         REAL,
  selection    TEXT NOT NULL,
  prob         REAL NOT NULL CHECK (prob >= 0 AND prob <= 1),
  fair_odds    REAL GENERATED ALWAYS AS (CASE WHEN prob > 0 THEN 1.0/prob END) VIRTUAL,
  lambda_home  REAL, lambda_away REAL,     -- soccer: medias Poisson usadas
  computed_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (event_id, model_run_id, market_code, line, selection)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_prediction_key
  ON prediction(event_id, model_run_id, market_code, COALESCE(line, -999), selection);

CREATE TABLE IF NOT EXISTS value_bet (     -- predicción cruzada contra el mejor momio disponible
  id            INTEGER PRIMARY KEY,
  prediction_id INTEGER NOT NULL REFERENCES prediction(id) ON DELETE CASCADE,
  odds_snapshot_id INTEGER NOT NULL REFERENCES odds_snapshot(id),
  book_prob_fair REAL NOT NULL,            -- implícita sin margen (Shin/proporcional)
  edge          REAL NOT NULL,             -- prob_modelo - book_prob_fair
  ev_per_unit   REAL NOT NULL,             -- prob*price - 1
  kelly_frac    REAL,                      -- fracción Kelly completa
  prob_model    REAL NOT NULL,             -- denormalizado de prediction.prob para rankear sin join
  n_books       INTEGER NOT NULL DEFAULT 1,-- casas que cotizaron esa selección (de v_best_price)
  confidence    REAL,                      -- 0–1: backtest de la liga × n_books × frescura del snapshot × cobertura de datos
  recommended   INTEGER NOT NULL DEFAULT 0,-- pasó umbral de edge + modelo validado
  reason        TEXT,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ───────────────────────── Track record de recomendaciones ─────────────────────────
-- Cada pick que el agente ENCONTRÓ (y si lo mostró) queda aquí, congelado con el precio y la probabilidad
-- del momento. `settle` lo liquida desde market_result. Es la base del "% de efectividad" por método.
CREATE TABLE IF NOT EXISTS recommendation (
  id            INTEGER PRIMARY KEY,
  event_id      INTEGER NOT NULL REFERENCES event(id),
  value_bet_id  INTEGER REFERENCES value_bet(id),
  model_run_id  INTEGER REFERENCES model_run(id),
  mode          TEXT NOT NULL CHECK (mode IN ('seguro','valor','combinado')),
  rank_in_mode  INTEGER,                   -- posición en el ranking de ese modo ese día
  market_code   TEXT NOT NULL REFERENCES market_type(code),
  line          REAL,
  selection     TEXT NOT NULL,
  prob_model    REAL NOT NULL,
  price_decimal REAL NOT NULL CHECK (price_decimal > 1.0),   -- mejor precio al momento de recomendar
  bookmaker_id  TEXT NOT NULL REFERENCES bookmaker(id),
  n_books       INTEGER,
  edge          REAL, ev_per_unit REAL, confidence REAL,
  stake_suggested REAL,
  why           TEXT,
  issued_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  was_shown     INTEGER NOT NULL DEFAULT 0,-- 1 = se le mostró a alguien (vs. sólo encontrado por el cron)
  shown_channel TEXT,                      -- 'whatsapp','telegram','app'
  shown_to      TEXT,                      -- id de usuario/guest (sin PII extra)
  -- liquidación (la llena `settle` desde market_result)
  outcome       TEXT CHECK (outcome IN ('win','loss','push','half_win','half_loss','void')),
  pnl_units     REAL,                      -- a 1 unidad plana al precio recomendado: win=price-1, loss=-1, push=0, half=±0.5×
  closing_price REAL, clv REAL, clv_benchmark_bookmaker_id TEXT REFERENCES bookmaker(id),
  settled_at    TEXT,
  -- Cuándo se le avisó al usuario de este pick. NULL = todavía no. Evita
  -- que el cron repita el mismo aviso cada 6 h hasta que el partido se juegue.
  notified_at   TEXT,
  -- Cuándo se le avisó que este pick se CERRÓ (aviso de resultado). NULL = todavía no.
  settled_notified_at TEXT,
  UNIQUE (event_id, mode, market_code, line, selection, issued_at)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_recommendation_key
  ON recommendation(event_id, mode, market_code, COALESCE(line, -999), selection, issued_at);
-- 007: una apuesta = UNA recomendación abierta (paridad con la migración 007).
CREATE UNIQUE INDEX IF NOT EXISTS ux_recommendation_open
  ON recommendation(event_id, mode, market_code, COALESCE(line, -999), selection)
  WHERE outcome IS NULL;
CREATE INDEX IF NOT EXISTS ix_reco_mode_settled ON recommendation(mode, settled_at);
CREATE INDEX IF NOT EXISTS ix_reco_event ON recommendation(event_id);

-- Efectividad por método (sólo liquidadas; void no cuenta en el denominador)
CREATE VIEW IF NOT EXISTS v_track_record_by_mode AS
  SELECT mode,
         COUNT(*)                                                     AS n,
         SUM(outcome IN ('win','half_win'))                           AS wins,
         SUM(outcome = 'push')                                        AS pushes,
         SUM(outcome IN ('loss','half_loss'))                         AS losses,
         ROUND(100.0 * SUM(outcome IN ('win','half_win')) / NULLIF(SUM(outcome <> 'push'),0), 1) AS hit_pct,
         ROUND(SUM(pnl_units), 2)                                     AS pnl_units,
         ROUND(100.0 * SUM(pnl_units) / COUNT(*), 1)                  AS roi_pct,
         ROUND(AVG(clv), 4)                                           AS avg_clv,
         ROUND(AVG(prob_model), 3)                                    AS avg_prob_model,
         MIN(issued_at) AS first_pick, MAX(issued_at) AS last_pick
  FROM recommendation
  WHERE outcome IS NOT NULL AND outcome <> 'void'
  GROUP BY mode;

-- Misma estadística desglosada por método × competencia × mercado (para "en Liga MX over/under voy 61 %")
CREATE VIEW IF NOT EXISTS v_track_record_detail AS
  SELECT r.mode, e.competition_id, r.market_code,
         COUNT(*) AS n,
         SUM(r.outcome IN ('win','half_win')) AS wins,
         SUM(r.outcome = 'push')              AS pushes,
         SUM(r.outcome IN ('loss','half_loss')) AS losses,
         ROUND(100.0 * SUM(r.outcome IN ('win','half_win')) / NULLIF(SUM(r.outcome <> 'push'),0), 1) AS hit_pct,
         ROUND(SUM(r.pnl_units), 2) AS pnl_units,
         ROUND(AVG(r.clv), 4) AS avg_clv
  FROM recommendation r JOIN event e ON e.id = r.event_id
  WHERE r.outcome IS NOT NULL AND r.outcome <> 'void'
  GROUP BY r.mode, e.competition_id, r.market_code;

-- Últimas N liquidadas con detalle (para mostrar "ganadas / empatadas / perdidas" una por una)
CREATE VIEW IF NOT EXISTS v_track_record_recent AS
  SELECT r.id, r.mode, e.kickoff_utc, e.competition_id,
         COALESCE(th.short_name, th.name) AS home,
         COALESCE(ta.short_name, ta.name) AS away,
         r.market_code, r.line, r.selection, r.price_decimal, r.bookmaker_id,
         r.prob_model, r.outcome, r.pnl_units, r.clv,
         r.clv_benchmark_bookmaker_id, mr.actual_value
  FROM recommendation r
  JOIN event e ON e.id = r.event_id
  JOIN team th ON th.id = e.home_team_id
  JOIN team ta ON ta.id = e.away_team_id
  LEFT JOIN market_result mr ON mr.event_id = r.event_id AND mr.market_code = r.market_code
       AND COALESCE(mr.line,-999) = COALESCE(r.line,-999) AND mr.selection = r.selection
  WHERE r.outcome IS NOT NULL AND r.outcome <> 'void'   -- 009: anuladas no son picks
  ORDER BY e.kickoff_utc DESC;

CREATE TABLE IF NOT EXISTS bet (           -- apuestas reales o en papel
  id            INTEGER PRIMARY KEY,
  event_id      INTEGER NOT NULL REFERENCES event(id),
  value_bet_id  INTEGER REFERENCES value_bet(id),
  bookmaker_id  TEXT NOT NULL REFERENCES bookmaker(id),
  market_code   TEXT NOT NULL REFERENCES market_type(code),
  line          REAL,
  selection     TEXT NOT NULL,
  stake         REAL NOT NULL,
  price_decimal REAL NOT NULL CHECK (price_decimal > 1.0),
  price_american INTEGER GENERATED ALWAYS AS (
                  CASE WHEN price_decimal >= 2.0 THEN CAST(ROUND((price_decimal - 1.0) * 100) AS INTEGER)
                       ELSE -CAST(ROUND(100.0 / (price_decimal - 1.0)) AS INTEGER) END) VIRTUAL,
  is_paper      INTEGER NOT NULL DEFAULT 1,
  placed_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  -- liquidación
  result        TEXT CHECK (result IN ('win','loss','push','half_win','half_loss','void')),
  pnl           REAL,
  closing_price REAL,                      -- precio de cierre del benchmark, misma selección/línea
  clv_benchmark_bookmaker_id TEXT REFERENCES bookmaker(id),  -- 'pinnacle' | 'betfair_ex' | 'market_avg' (cascada si el sharp no publicó ese mercado)
  clv           REAL,                      -- (price/closing_fair - 1) medido contra el benchmark sin margen
  settled_at    TEXT
);
CREATE INDEX IF NOT EXISTS ix_bet_event ON bet(event_id);

CREATE TABLE IF NOT EXISTS bankroll_ledger (
  id         INTEGER PRIMARY KEY,
  ts         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  kind       TEXT NOT NULL CHECK (kind IN ('deposit','withdraw','stake','payout','adjust')),
  amount     REAL NOT NULL,
  bet_id     INTEGER REFERENCES bet(id),
  balance_after REAL NOT NULL,
  note       TEXT
);

-- Trabajos de recolección por liga (backfill inicial acotado + sync continuo). Reanudables por chunk.
CREATE TABLE IF NOT EXISTS collection_job (
  id             INTEGER PRIMARY KEY,
  competition_id TEXT NOT NULL REFERENCES competition(id),
  kind           TEXT NOT NULL CHECK (kind IN ('backfill','sync_fixtures','odds_snapshot','settle')),
  range_from     TEXT, range_to TEXT,      -- para backfill: collect_since → hoy, en chunks por temporada
  status         TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','running','done','error','cancelled')),
  progress_json  TEXT,                     -- {"seasons_done":["2024","2025"],"fixtures":612,"stats":540,"requests":1210}
  requests_used  INTEGER NOT NULL DEFAULT 0,
  requested_by   TEXT,
  created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  started_at     TEXT, finished_at TEXT,
  error          TEXT
);
CREATE INDEX IF NOT EXISTS ix_collection_job_status ON collection_job(status, kind);

-- Inventario vs recolección: lo que el agente le puede ofrecer al usuario
CREATE VIEW IF NOT EXISTS v_competition_inventory AS
  SELECT c.id, c.sport_id, c.country_code, co.name AS country, c.name, c.tier, c.logo_url, co.flag_url,
         c.collect_enabled, c.collect_since, c.history_years, c.backfill_status,
         (SELECT COUNT(*) FROM event e WHERE e.competition_id = c.id)                       AS events_stored,
         (SELECT COUNT(*) FROM event e WHERE e.competition_id = c.id AND e.status='finished') AS events_finished,
         (SELECT MAX(kickoff_utc) FROM event e WHERE e.competition_id = c.id)              AS last_event
  FROM competition c LEFT JOIN country co ON co.code = c.country_code
  WHERE c.active = 1;

-- Bitácora de ingestas (idempotencia + presupuesto de créditos)
CREATE TABLE IF NOT EXISTS ingest_log (
  id          INTEGER PRIMARY KEY,
  provider_id TEXT NOT NULL REFERENCES provider(id),
  job         TEXT NOT NULL,               -- 'sync_fixtures','odds_snapshot','settle','backfill'
  scope       TEXT,                        -- competition/season/week
  started_at  TEXT NOT NULL,
  finished_at TEXT,
  rows_written INTEGER DEFAULT 0,
  credits_used INTEGER DEFAULT 0,
  credits_remaining INTEGER,
  status      TEXT NOT NULL DEFAULT 'ok',
  error       TEXT
);

-- Preferencias del agente / dueño (1 fila por clave)
CREATE TABLE IF NOT EXISTS setting (
  key   TEXT PRIMARY KEY,                  -- 'odds_format','bankroll','min_edge','kelly_fraction','max_stake_pct','locale'
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
INSERT OR IGNORE INTO setting(key,value) VALUES
  ('odds_format','decimal'),               -- 'decimal' | 'american' | 'both'
  ('bankroll','1000'),
  ('min_edge','0.03'),
  ('kelly_fraction','0.25'),
  ('max_stake_pct','0.05'),
  ('notify_picks','on'),
  ('notify_min_edge','0.03'),
  ('notify_min_confidence','0.5'),
  ('max_history_years','2'),               -- tope duro: nunca más de 2 años hacia atrás desde la solicitud
  ('max_enabled_competitions','12'),       -- tope de ligas encendidas a la vez (presupuesto de requests)
  ('locale','es-MX'),
  ('timezone','America/Mexico_City');       -- IANA u offset 'UTC-06:00'; config-sync lo siembra desde el perfil del dueño

-- Foto de estado materializada: la refresca cada corrida que mueve datos y
-- el agente la lee de un tiro (ver migrations/003). Una sola fila.
CREATE TABLE IF NOT EXISTS status_snapshot (
  id           INTEGER PRIMARY KEY CHECK (id = 1),
  payload      TEXT NOT NULL,
  computed_at  TEXT NOT NULL,
  computed_by  TEXT
);

CREATE TABLE IF NOT EXISTS schema_version (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
INSERT OR IGNORE INTO schema_version VALUES (8, strftime('%Y-%m-%dT%H:%M:%fZ','now'));
CREATE INDEX IF NOT EXISTS ix_recommendation_settled_notice
  ON recommendation(settled_notified_at, settled_at);
