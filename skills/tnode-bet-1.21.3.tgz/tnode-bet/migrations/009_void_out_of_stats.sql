-- 009: una recomendación anulada (outcome = 'void') no es un pick.
--
-- En HEB β se anularon 19 picks emitidos por el bug de equipos duplicados
-- (prob 1.0, edges de 0.2 a 0.86; tnode-bet 1.19.0, 2026-09-12→14). No se
-- tomaron decisiones con ellos, así que no pueden contar como emitidos, ni
-- como "empate", ni aparecer en "recientes": ensuciarían la medición real de
-- la efectividad. by_mode y detail ya los excluían; recent no.

DROP VIEW IF EXISTS v_track_record_recent;
CREATE VIEW v_track_record_recent AS
  SELECT r.id, r.mode, e.kickoff_utc, e.competition_id,
         COALESCE(th.short_name, th.name) AS home,
         COALESCE(ta.short_name, ta.name) AS away,
         r.market_code, r.line, r.selection, r.price_decimal, r.bookmaker_id,
         r.prob_model, r.outcome, r.pnl_units, r.clv,
         r.clv_benchmark_bookmaker_id, mr.actual_value
  FROM recommendation r
  JOIN event e ON e.id = r.event_id
  JOIN team th ON th.id = e.home_team_id
  JOIN team ta ON ta.id = e.away_team_id
  LEFT JOIN market_result mr ON mr.event_id = r.event_id
       AND mr.market_code = r.market_code
       AND COALESCE(mr.line,-999) = COALESCE(r.line,-999)
       AND mr.selection = r.selection
  WHERE r.outcome IS NOT NULL AND r.outcome <> 'void'
  ORDER BY e.kickoff_utc DESC;
