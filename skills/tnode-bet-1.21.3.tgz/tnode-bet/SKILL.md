---
name: tnode-bet
description: Apuestas deportivas de Fútbol Soccer y NFL — historial de partidos con momios de cierre, cómo salió cada mercado, qué tan seguido pega una línea, y qué ligas cubres o puedes activar. Úsalo SIEMPRE que te pregunten por equipos, resultados, rachas, momios, mercados o apuestas; nunca inventes datos ni des pronósticos de memoria.
---

# tnode-bet

Base de datos propia de **fútbol soccer y NFL**: catálogo de ligas, mercados
y casas de apuestas, más el historial que el nodo va construyendo partido a
partido. Todo lo que respondas sobre cobertura, mercados o momios sale de
aquí — **nunca de tu memoria ni de una búsqueda web**.

## Lo PRIMERO que debes correr

Antes de responder cualquier cosa de apuestas, corre `status`. Te dice en un
solo tiro qué ligas tienes cargadas, con cuántos partidos y desde cuándo, qué
tan seguido pega cada mercado, cuándo fue la última carga y qué te falta. Es
una foto guardada, así que es barato: úsala en vez de adivinar.

## Cuándo usarlo

- Te preguntan por un **equipo**: cómo va, sus últimos partidos, contra quién,
  si viene ganando.
- Te preguntan **cada cuánto pega** un mercado: «¿cuántas veces hay over 2.5
  en la Premier?», «¿el local gana seguido en la NFL?».
- Te preguntan **qué ligas cubres**, o piden **activar** una nueva.
- Te preguntan por **momios, mercados o apuestas** de cualquier tipo.
- Te preguntan por el **estado del skill** o por qué no tienes datos.

## Cómo invocar

```bash
SKILL=~/.openclaw/workspace/skills/tnode-bet/bin/bet.py

python3 $SKILL status                       # ⭐ EMPIEZA AQUÍ: foto completa del estado
python3 $SKILL status --refresh             # recalcula la foto (sólo si algo se ve viejo)

# Historial (lo que ya está cargado en la base)
python3 $SKILL teams --search chiefs        # resuelve "Chiefs" al nombre real
python3 $SKILL team "Kansas City Chiefs" --last 10
python3 $SKILL team america --vs chivas --last 5      # historial entre dos equipos
python3 $SKILL history --market GOALS_OU --line 2.5 --competition epl
python3 $SKILL history --market TOTAL --competition nfl --season 2025
python3 $SKILL markets --with-history       # qué mercados tienen historial

# Valor: dónde conviene apostar
python3 $SKILL value --mode combinado --limit 5
python3 $SKILL value --mode seguro --competition ligamx
python3 $SKILL card --event <id>            # tarjeta de un partido
python3 $SKILL analyze --event <id> [--market GOALS_OU]

# Picks ABIERTOS (pendientes de resultado) y LIQUIDADOS (efectividad)
python3 $SKILL report track-record [--mode seguro] [--competition ligamx] [--last 10]

# En vivo (lo alimenta el cron solo; consúltalo, no lo dispares sin motivo)
python3 $SKILL quota                        # cuánta cuota de api-sports queda

python3 $SKILL leagues list --collecting    # las que SÍ se recolectan
python3 $SKILL leagues discover --country México   # ⭐ qué ligas HAY en el proveedor para un país (sólo con momios)
python3 $SKILL leagues discover --country ES --search femen
python3 $SKILL leagues enable api:673 --by <quien lo pidió>   # prende una liga por su id del proveedor (la da discover)
python3 $SKILL leagues enable ligamx --by <quien lo pidió>    # o por su id local
python3 $SKILL leagues disable seriea
python3 $SKILL leagues status               # avance de las cargas históricas
python3 $SKILL doctor                       # diagnóstico si algo falla
python3 $SKILL settings get
python3 $SKILL settings set --key odds_format --value american
python3 $SKILL odds convert --price -110    # decimal <-> americano
```

Todo devuelve **JSON**. Tradúcelo a lenguaje natural, en español. Si el JSON
trae `summary` o `message`, **úsalo como base de tu respuesta**: ya viene con
los números correctos.

Formato según el canal: por **WhatsApp o Telegram**, texto plano sin markdown
ni tablas. En el **chat de la app** puedes usar negritas y viñetas.

## Ligas: inventario vs recolección

Hay **cientos de ligas en el inventario**, pero el nodo sólo recolecta las
que están encendidas (de fábrica: Liga MX, Premier League, LaLiga y NFL).
Esto es a propósito: traer el mundo entero saturaría la base sin que nadie
lo consulte.

Cuando te pregunten **qué ligas tienes de un país** («¿qué ligas tienes en
México?») o por una liga que no recolectas:

1. Corre `leagues discover --country <país tal como lo dijo>`. Devuelve las
   ligas del proveedor **que sí tienen momios** (las que no, no se ofrecen:
   sin momios no hay CLV ni picks, y el JSON dice cuántas ocultó). Cada fila
   trae `enable_with`: el argumento exacto para prenderla.
2. Preséntalas con su nombre real y di cuáles ya recolectas (`collecting`).
3. Si piden activar una («activa la Liga MX Femenil»), **ofrece activarla** y
   di qué implica: se cargan los últimos 2 años de historial **en el acto**
   (unos segundos) y los momios llegan con el siguiente cron (cada 6 h).
4. Actívala **sólo si el usuario dice que sí**, con
   `leagues enable <enable_with> --by <quien lo pidió>` (p.ej.
   `leagues enable api:673`). NUNCA inventes ids: úsalos tal cual los devolvió
   `discover`.
5. Si `leagues enable` devuelve `max_enabled_reached`, dile cuántas ligas
   están encendidas y pídele cuál apagar antes de prender la nueva. Si
   devuelve `sin_momios`, explica que esa liga no se puede activar porque el
   proveedor no publica momios y ofrece las de `discover`.

El tope de 2 años de historial **no es negociable** desde el chat. Si te
piden 10 años, explica que el arranque de cada liga carga 2 años y que de
ahí en adelante el historial crece solo, día con día.

Apagar una liga **no borra nada**: si la vuelven a prender, el historial
sigue ahí.

## Horas: di `hora_local`, nunca conviertas

Los partidos se guardan en UTC (`kickoff_utc`), pero cada salida trae al
lado **`hora_local`** ya redactada en la zona del usuario («sáb 6 sep,
5:00 pm») y `kickoff_local` con offset. **Di `hora_local` tal cual.** No
sumes ni restes horas, no menciones UTC, no digas «hora del centro» si no
te lo piden. La zona usada viene en `zona_horaria`; si el usuario dice que
está en otra parte, corre el comando con `--tz <zona>` (p.ej. `--tz
America/Bogota`) en vez de calcular.


La base guarda todo en **decimal**; el americano se calcula al vuelo. El
formato que ve el usuario lo manda `settings.odds_format` (`decimal`,
`american` o `both`). Si te piden «muéstramelos en americano», cámbialo con
`settings set --key odds_format --value american` y confírmalo.

Para convertir un momio suelto que te dé el usuario, usa `odds convert` —
no lo calcules de cabeza.

## ⛔ NUNCA cuentes tú: los números ya vienen calculados

Esta es la regla que más se rompe y la que más caro sale. **Jamás derives un
número contando los partidos de la lista.** Todo conteo que necesites ya
viene en el campo `resumen`:

- récord (`ganados` / `empatados` / `perdidos`)
- `racha` actual, con cuántos partidos lleva y de qué tipo
- `handicap`: cuántas veces `cubrio` y cuántas `no_cubrio`, sobre `de`
- `total`: cuántos `over` y cuántos `under`
- `como_local` y `como_visitante` por separado
- promedios de puntos o goles a favor y en contra

Si el número que quieres decir **no está en `resumen`**, no lo digas. Pide el
dato con otro comando (`history`) o descríbelo sin cifra.

Dos trampas reales, medidas:

1. **Ganar un partido no es cubrir el hándicap.** Un equipo puede ganar y aun
   así no cubrir si era favorito por más de su margen. Si cuentas «los que
   ganó», te va a dar distinto que `handicap.cubrio`.
2. **Una racha se corta con un solo resultado distinto.** No metas un partido
   perdido dentro de una racha de victorias porque el marcador se parezca.

El campo `summary` ya trae la frase armada con los números correctos. Úsala
como base y adórnala con el detalle de los partidos, nunca al revés.

## Cómo leer lo que devuelve `team`

Cada partido trae los mercados **desde la perspectiva del equipo que
consultaste**, no del local. No tienes que deducir nada:

- `moneyline`: si ese equipo ganó o perdió.
- `handicap`: su línea (negativa = era favorito, positiva = era underdog) y
  si `cubrió` o `no cubrió`.
- `total`: la línea de goles o puntos, cuántos hubo de verdad, y si salió
  `over` o `under`.
- `ambos_anotan`: sólo en fútbol.

## Cómo leer `history`

Es la **tasa base**: cada cuánto pegó ese mercado en el historial ya cargado.
Sirve para responder con números en vez de con intuición («el over 2.5 en la
Premier pegó 48 % de 380 partidos»). Siempre di **cuántos partidos** son: un
porcentaje sin muestra no significa nada.

Ojo: la tasa base **no es un pronóstico**. Es lo que pasó, no lo que va a
pasar.

## Momios en vivo

El nodo toma una foto de los momios cada 6 horas y guarda los partidos por
venir. Cuando te pregunten «¿cómo pagan?» o «¿qué momio hay?», los datos
**ya están en la base**: no llames al proveedor, sólo consulta.

Cuando des un momio, di **siempre** de qué casa es y de cuándo. Un precio sin
casa no significa nada, y los precios se mueven.

## Picks: qué comando según la pregunta

Hay TRES preguntas distintas que suenan parecido. Cada una tiene su comando
y los números ya vienen calculados; tú sólo los narras.

| Te preguntan | Corre | Lee |
|---|---|---|
| «¿Cuáles son los picks?», «¿qué apuesto hoy?», «¿dónde hay valor?» | `value --mode combinado --limit 5` | `picks[]`: partido, apuesta, mejor precio CON casa, ventaja y porqué |
| «¿Qué picks tengo **abiertos / pendientes**?», «¿qué falta por jugarse?» | `report track-record` | `abiertas[]` + `resumen_abiertas` |
| «¿Cómo vas?», «¿cuántos has **ganado / perdido**?», «¿qué tan efectivo eres?» | `report track-record` | `summary`, `por_modo[]`, `recientes[]` |
| «¿Qué picks se **cerraron** hace poco?», «¿cómo salió el de anoche?» | `report settled --last 10` | `picks[]` con `resultado`, `unidades`, `prob_modelo`, `edge`, `clv`; `acumulado` |

`value` recalcula con los momios de AHORA; `abiertas` es lo que se recomendó
tal como se congeló (precio, casa y probabilidad de ese momento). No son lo
mismo y no debes mezclarlos: si te piden los pendientes, no corras `value`.

`value` trae además `partidos_sin_historial[]`: partidos donde algún equipo
tiene muy pocos partidos en la base (recién ascendido o recién agregado). De
esos NO salen picks a propósito — si preguntan por uno, di que todavía no hay
datos suficientes del equipo, no que «no hay valor». En `analyze`/`card`, una
oportunidad con `bloqueada` (`equipo_sin_historial` o `edge_inverosimil`) se
muestra sólo como dato; nunca la presentes como recomendación.

Una liga sólo da picks si, en su backtest, el modelo (mezclado con el
mercado) le ganó al cierre de Pinnacle. `value` trae `ligas_sin_ventaja` con
el motivo (`liga_sin_backtest`, `liga_muestra_corta` o
`liga_no_supera_mercado`): si preguntan por
esa liga, di que por ahora el modelo no le gana al mercado ahí y que por eso
no sugieres apuestas — no inventes un pick. `prob_modelo` ya viene anclada al
mercado (`peso_modelo` = cuánto pesa el modelo); `prob_modelo_puro` es sólo
referencia.

Al leer `report track-record`:

- **`resumen_abiertas` ya trae los conteos** (`total`, `partidos`,
  `por_partido`, `avisadas`, `proximo_kickoff_utc`). No cuentes la lista.
- **`summary` ya trae la frase de efectividad** con el récord y, si la
  muestra alcanza (`muestra_minima`), el acierto, las unidades, el ROI y el
  CLV. Si dice «muestra corta», repítelo así: con pocos picks el porcentaje
  no significa nada, y decir «100 % de efectividad» con un pick es engañar.
- **El acierto NUNCA va solo**: siempre con unidades/ROI y CLV. CLV negativo
  con buen acierto = se ganó por suerte; dilo.
- Un pick con `ya_empezo: true` está en juego o esperando que el cron de
  resultados lo liquide (corre cada hora); no lo des por perdido ni ganado.
- Si `abiertas` viene vacía y `por_modo` también, di que todavía no hay
  recomendaciones emitidas — no que «el motor no está conectado».

**No uses `web_search`** para suplir nada de esto: un momio sacado de una
página no es comparable con el resto de la base y contamina el historial.

## Reglas al hablar de apuestas

- **Para avisarle al dueño, sólo responde.** Lo que escribes en el chat ya
  llega a la app y suena el teléfono. **Nunca** uses la herramienta `message`
  por el canal `tnode` (su destino es un uid de Firebase, no un correo ni un
  teléfono; da `403 PERMISSION_DENIED` y ese 403 no es un problema de la
  cuenta), y **nunca** crees automations o crons propios para avisos: el skill
  ya trae los suyos — **picks nuevos** cada 6 h y **picks cerrados** cada hora
  (resultado, unidades, probabilidad, ventaja y CLV, vía
  `report settled --only-new`). Si te piden otro aviso, di cuáles existen,
  anota la petición y no armes nada.
- **Las ligas encendidas entran solas a todas las corridas** (fixtures,
  momios, resultados, picks nuevos y cerrados). Para cubrir una liga se
  enciende con `leagues enable`, nunca con un cron aparte por liga.

- **La app se llama «la app TNode»**, nunca «OpenClaw». Si te escriben por
  WhatsApp, responde ahí mismo con los picks; no mandes al usuario a la app.
- **Nunca prometas ganancias ni des «fijas».** Todo pick va con
  probabilidad, mejor precio, casa y el porqué, tal como vienen del JSON.
- **Sólo mayores de edad.** Si detectas que quien pregunta es menor, no
  continúes con el tema.
- **Nunca insistas.** Si el usuario no pregunta por apuestas, no las
  ofrezcas.
- El skill **no apuesta ni tiene cuenta en ninguna casa**: sólo analiza
  precios públicos. Dilo si te lo preguntan.

## Errores que DEBES manejar

- `db_not_found` → el skill no está instalado en este nodo. Dile al dueño
  que lo active desde la app TNode; no intentes instalarlo tú.
- `team_not_found` → ese equipo no está en el historial cargado. Di de qué
  ligas SÍ tienes datos (`status`) y ofrece buscar con otro nombre.
- `sin_historial` → el mercado existe pero esa liga aún no tiene partidos
  cargados. Dilo, no lo confundas con «el mercado no existe».
- `competition_not_found` → esa liga no está en el inventario local. Búscala
  en el proveedor con `leagues discover --country <país>` y préndela con el
  `enable_with` que te devuelva.
- `sin_momios` → la liga existe pero el proveedor no publica momios: no se
  activa (sin momios no hay CLV ni picks). Ofrece otra.
- `api_league_not_found` → ese id no existe en el proveedor; vuelve a
  `discover` y usa un id de ahí.
- `max_enabled_reached` → ya hay demasiadas ligas encendidas; pide cuál
  apagar.
- `max_history_years_capped` → te pidieron más historial del permitido;
  explica el tope de 2 años.
- Si `doctor` marca `ok: false`, resume en una línea qué revisó y qué
  falló, y dile al dueño que lo revise desde la app.
