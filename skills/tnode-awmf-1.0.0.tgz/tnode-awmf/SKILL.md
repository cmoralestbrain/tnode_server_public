---
name: tnode-awmf
description: Asistente para Tarjetas de trabajo del motor de flujos — acuña citas verificables y valida tu evidencia antes de reportar con awmf_result. Úsalo en toda tarjeta que pida evidencia.
---

# tnode-awmf

Asistente para resolver **Tarjetas de trabajo del motor de flujos** (los
turnos que empiezan con "[Tarjeta de trabajo del motor de flujos…]").
Te da dos comandos locales: **acuñar citas verificables** y **validar tu
evidencia** antes de reportar. Úsalo en TODA tarjeta que pida evidencia.

## Cuándo usarlo

- **Al citar una fuente** (encontraste una fila, o confirmaste que algo
  NO está): `cita` te da la evidencia con la gramática EXACTA que el
  motor verifica. Nunca escribas una cita a mano.
- **Antes de reportar con la herramienta awmf_result**: `validar` revisa
  la forma de tu evidencia. Si aquí sale un problema, corrígelo y vuelve
  a validar — te ahorra un intento rechazado por el motor.

## Cómo invocar

```bash
SKILL=~/.openclaw/workspace/skills/tnode-awmf/bin/awmf.py

# Encontraste la fila 7 de la hoja CLIENTES (7 = fila real del
# spreadsheet: encabezado es 1, datos desde 2):
python3 $SKILL cita fila --hoja CLIENTES --fila 7 --valor "Teléfono=5213349441400"

# Buscaste y NO está (la columna Teléfono no contiene ese valor;
# usa --valor any si la columna está vacía para todos):
python3 $SKILL cita ausencia --hoja CLIENTES --columna "Teléfono" --valor any

# Pre-flight de la evidencia completa antes de reportar:
python3 $SKILL validar --evidencia '{"origin":"sheet:CLIENTES:row:7","resolved":{"Teléfono":"5213349441400"}}'
```

`cita` imprime `{"ok": true, "evidence": {…}}` — ese objeto `evidence`
es el que reportas. `validar` imprime `{"ok": true}` o la lista de
problemas con cómo arreglar cada uno.

## Reglas

1. **La evidencia se OBTIENE, jamás se redacta.** Cada valor sale de una
   herramienta o de una fuente: el `approvalId` (forma `ap_…`) lo
   devuelve request_approval; el `messageId` lo devuelve guest_send; la
   fila y sus celdas salen de la hoja que leíste. Si no tienes el valor
   real, NO tienes la evidencia — reporta el problema, no un valor
   parecido.
2. **`resolved` lleva las celdas TAL CUAL** las leíste (el motor las
   coteja una por una contra la fuente). En una ausencia, lleva el par
   que buscaste.
3. **Consultar es libre, actuar no.** Para leer fuentes usa tus
   habilidades (p. ej. Drive). Las acciones con efectos (enviar, escribir,
   cobrar) van SOLO por las herramientas permitidas de la tarjeta.
4. **Toda tarjeta termina con la herramienta awmf_result** — logrado
   ("done" + evidencia validada), no alcanzó ("failed" + motivo) o
   inejecutable tal como llegó ("refused" + motivo accionable). Un
   "failed" o "refused" honesto es una salida correcta; un "done"
   inventado no pasa la verificación del motor y regresa como reemisión.
5. Si `validar` dice ok pero el motor rechaza, el motivo REAL vendrá en
   la reemisión: este script valida la FORMA; la verdad de los valores
   la verifica el motor contra la fuente.
