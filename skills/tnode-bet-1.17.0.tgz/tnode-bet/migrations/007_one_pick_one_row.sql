-- 007: una apuesta = una recomendación.
--
-- Cada `value` (el cron de picks cada 6 h y el agente cada vez que alguien
-- le preguntaba) insertaba OTRA fila para la misma apuesta. El 2026-09-06 el
-- pick "Atlas vs Atlante — X2" existía 5 veces, las 5 liquidadas como
-- ganadas, y el estatus presumía "combinado: 5 de 5, 100 %, ROI 80 %"
-- cuando en realidad era UN pick. Un track record inflado es peor que no
-- tenerlo: es justo lo que el usuario usa para decidir si confía.
--
-- Colapsa las duplicadas conservando la PRIMERA emisión (el precio que el
-- usuario pudo haber tomado) y heredándole el aviso si alguna copia ya se
-- notificó. Luego un índice único parcial sobre las abiertas para que no
-- vuelva a pasar aunque el código se equivoque.

UPDATE recommendation SET
  notified_at = (SELECT MIN(r2.notified_at) FROM recommendation r2
                  WHERE r2.event_id = recommendation.event_id
                    AND r2.mode = recommendation.mode
                    AND r2.market_code = recommendation.market_code
                    AND COALESCE(r2.line, -999) = COALESCE(recommendation.line, -999)
                    AND r2.selection = recommendation.selection),
  was_shown   = (SELECT MAX(r2.was_shown) FROM recommendation r2
                  WHERE r2.event_id = recommendation.event_id
                    AND r2.mode = recommendation.mode
                    AND r2.market_code = recommendation.market_code
                    AND COALESCE(r2.line, -999) = COALESCE(recommendation.line, -999)
                    AND r2.selection = recommendation.selection)
WHERE id IN (SELECT MIN(id) FROM recommendation
             GROUP BY event_id, mode, market_code, COALESCE(line, -999), selection);

DELETE FROM recommendation
WHERE id NOT IN (SELECT MIN(id) FROM recommendation
                 GROUP BY event_id, mode, market_code, COALESCE(line, -999), selection);

CREATE UNIQUE INDEX IF NOT EXISTS ux_recommendation_open
  ON recommendation(event_id, mode, market_code, COALESCE(line, -999), selection)
  WHERE outcome IS NULL;
