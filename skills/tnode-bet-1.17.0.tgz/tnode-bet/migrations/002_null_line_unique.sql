-- 002: los mercados SIN línea (1X2, ML, BTTS, DC, DNB, par/impar) se
-- duplicaban al re-correr el backfill.
--
-- Causa: en SQLite NULL nunca es igual a NULL, ni siquiera dentro de una
-- PRIMARY KEY o un UNIQUE. Así que `INSERT OR REPLACE` con `line = NULL`
-- nunca encontraba conflicto y apilaba una fila nueva en cada pasada.
-- Medido: +1710 filas por cada re-corrida del backfill de NFL (855 partidos
-- x 2 selecciones de moneyline).
--
-- Fix: un índice único sobre COALESCE(line,-999), que sí colapsa los nulos.
-- Se deduplica primero (nos quedamos con la fila más reciente de cada llave)
-- porque si no, el índice no puede crearse.

DELETE FROM market_result WHERE rowid NOT IN (
  SELECT MAX(rowid) FROM market_result
  GROUP BY event_id, market_code, COALESCE(line, -999), selection);
CREATE UNIQUE INDEX IF NOT EXISTS ux_market_result_key
  ON market_result(event_id, market_code, COALESCE(line, -999), selection);

DELETE FROM prediction WHERE rowid NOT IN (
  SELECT MAX(rowid) FROM prediction
  GROUP BY event_id, model_run_id, market_code, COALESCE(line, -999), selection);
CREATE UNIQUE INDEX IF NOT EXISTS ux_prediction_key
  ON prediction(event_id, model_run_id, market_code, COALESCE(line, -999), selection);

DELETE FROM recommendation WHERE rowid NOT IN (
  SELECT MAX(rowid) FROM recommendation
  GROUP BY event_id, mode, market_code, COALESCE(line, -999), selection, issued_at);
CREATE UNIQUE INDEX IF NOT EXISTS ux_recommendation_key
  ON recommendation(event_id, mode, market_code, COALESCE(line, -999), selection, issued_at);
