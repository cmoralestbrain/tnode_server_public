-- 004: ids reales de api-sports, verificados contra el proveedor 2026-09-06.
--
-- Los de MERCADO estaban todos bien (1, 4, 5, 6, 7, 8, 10, 12, 13, 16, 17,
-- 21, 27, 28, 45). Los de CASA no: dos estaban mal y uno chocaba.
--
--   Pinnacle    4  ✓ (era correcto)
--   Bet365      8  ✓ (era correcto)
--   Marathonbet 2  ✗ estaba como 3 — y el 3 es Betfair, así que además
--                    colisionaba y habría atribuido momios a la casa equivocada
--   1xBet      11  ✗ estaba como 6 — el 6 es Bwin
--
-- De ahí la columna `verified`: los supuestos se marcan 0 hasta comprobarlos.

UPDATE external_id SET external_id = '2'
  WHERE entity_type='bookmaker' AND entity_id='marathonbet' AND provider_id='api_football';
UPDATE external_id SET external_id = '11'
  WHERE entity_type='bookmaker' AND entity_id='onexbet' AND provider_id='api_football';

INSERT OR IGNORE INTO bookmaker (id,name,is_sharp,region,active) VALUES
 ('bwin','Bwin',0,'eu',1),
 ('williamhill','William Hill',0,'uk',1),
 ('betsson','Betsson',0,'eu',1),
 ('betano','Betano',0,'eu',1),
 ('betcris','Betcris',0,'mx',1);

INSERT OR IGNORE INTO external_id VALUES
 ('bookmaker','betfair_ex','api_football','3'),
 ('bookmaker','bwin','api_football','6'),
 ('bookmaker','williamhill','api_football','7'),
 ('bookmaker','betsson','api_football','26'),
 ('bookmaker','betano','api_football','32'),
 ('bookmaker','betcris','api_football','20');

-- Tarjetas: el mercado existía en el catálogo pero sin mapeo al proveedor.
INSERT OR IGNORE INTO provider_market_map VALUES
 ('api_football','80','Cards Over/Under','CARDS_OU',
  '{"Over":"over","Under":"under"}', '^(Over|Under) (\d+(?:\.\d+)?)$', 1);

-- Todo lo verificado deja de ser un supuesto.
UPDATE provider_market_map SET verified = 1
 WHERE provider_id = 'api_football'
   AND external_market_id IN ('1','4','5','6','7','8','10','12','13','16','17','21','27','28','45','80');

-- `Draw No Bet` NO existe como mercado de partido completo en api-sports
-- (sólo por mitades: 109 y 182). El catálogo lo conserva porque el MODELO sí
-- lo cotiza y football-data lo liquida; simplemente no llegará del proveedor.
DELETE FROM provider_market_map
 WHERE provider_id = 'api_football' AND market_code = 'DNB';
