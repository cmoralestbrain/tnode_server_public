-- 005: la vista de recomendaciones recientes mostraba los equipos en blanco.
--
-- Usaba `short_name`, que sólo se llena en NFL (nflverse trae la abreviatura).
-- Los equipos de fútbol entran por football-data y api-sports, que dan el
-- nombre completo y ningún corto — así que la vista devolvía NULL y el agente
-- habría dicho "None vs None".
--
-- COALESCE al nombre completo. Además se agregan el CLV y la casa contra la
-- que se midió: sin eso, una recomendación reciente no se puede juzgar.

DROP VIEW IF EXISTS v_track_record_recent;
CREATE VIEW v_track_record_recent AS
  SELECT r.id, r.mode, e.kickoff_utc, e.competition_id,
         COALESCE(th.short_name, th.name) AS home,
         COALESCE(ta.short_name, ta.name) AS away,
         r.market_code, r.line, r.selection, r.price_decimal, r.bookmaker_id,
         r.prob_model, r.outcome, r.pnl_units, r.clv,
         r.clv_benchmark_bookmaker_id, mr.actual_value
  FROM recommendation r
  JOIN event e ON e.id = r.event_id
  JOIN team th ON th.id = e.home_team_id
  JOIN team ta ON ta.id = e.away_team_id
  LEFT JOIN market_result mr ON mr.event_id = r.event_id
       AND mr.market_code = r.market_code
       AND COALESCE(mr.line,-999) = COALESCE(r.line,-999)
       AND mr.selection = r.selection
  WHERE r.outcome IS NOT NULL
  ORDER BY e.kickoff_utc DESC;
