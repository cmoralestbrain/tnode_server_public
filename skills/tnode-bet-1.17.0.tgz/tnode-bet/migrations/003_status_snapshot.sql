-- 003: foto de estado materializada.
--
-- `status` recalculaba todo con COUNT(*) en vivo: barato con 3 mil partidos,
-- caro cuando la base tenga millones de momios, y encima no decía nada de
-- efectividad. Ahora cada corrida que mueve datos (install, backfill, settle)
-- deja aquí una foto lista para leer, y el agente la consulta de un tiro.
--
-- Una sola fila por diseño (id=1): es un cache, no un histórico.

CREATE TABLE IF NOT EXISTS status_snapshot (
  id           INTEGER PRIMARY KEY CHECK (id = 1),
  payload      TEXT NOT NULL,          -- JSON: ligas, totales, cobertura, efectividad
  computed_at  TEXT NOT NULL,
  computed_by  TEXT                    -- qué corrida la dejó: install | backfill | settle | manual
);
