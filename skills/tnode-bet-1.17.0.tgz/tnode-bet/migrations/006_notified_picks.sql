-- 006: marca de "ya avisé de este pick".
--
-- Sin esto, el cron cada 6 h volvería a anunciar los MISMOS picks del mismo
-- partido una y otra vez hasta que se juegue. Cuatro avisos idénticos al día
-- por un solo partido es la forma más rápida de que el usuario silencie las
-- notificaciones — y entonces la función deja de servir para siempre.
--
-- La llave del aviso es (partido, mercado, línea, selección): si el precio se
-- movió pero es la misma apuesta, NO se vuelve a anunciar.

ALTER TABLE recommendation ADD COLUMN notified_at TEXT;
CREATE INDEX IF NOT EXISTS ix_recommendation_notified
  ON recommendation(notified_at, event_id);

INSERT OR IGNORE INTO setting(key, value) VALUES
  ('notify_picks', 'on'),          -- 'on' | 'off'
  ('notify_min_edge', '0.03'),     -- ventaja mínima para molestar al usuario
  ('notify_min_confidence', '0.5');
